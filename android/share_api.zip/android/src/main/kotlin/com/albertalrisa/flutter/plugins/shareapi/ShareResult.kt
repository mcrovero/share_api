package com.albertalrisa.flutter.plugins.shareapi

object ShareResult {
    const val Undefined = 0x00
    const val Ok = 0x01
    const val Canceled = 0x02
    const val Failed = 0x03
}
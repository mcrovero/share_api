package com.albertalrisa.flutter.plugins.shareapi.requests

const val FACEBOOK_SHARE_TO_STORY = 5201
package com.albertalrisa.flutter.plugins.shareapi.requests

const val INSTAGRAM_SHARE_TO_STORY = 5301
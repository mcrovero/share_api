package com.albertalrisa.flutter.plugins.shareapi.requests

const val SYSTEMUI_SHARE_TEXT = 5101
const val SYSTEMUI_SHARE_IMAGE = 5102
const val SYSTEMUI_SHARE_FILE = 5103
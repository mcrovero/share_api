package com.albertalrisa.flutter.plugins.shareapi.requests

const val WHATSAPP_SHARE_TEXT = 5401
const val WHATSAPP_SHARE_IMAGE = 5402
const val WHATSAPP_SHARE_TEXT_IMAGE = 5403